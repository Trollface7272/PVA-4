package tlacitka;

public interface I_Algoritmus {
    public void Algoritmus();
}
