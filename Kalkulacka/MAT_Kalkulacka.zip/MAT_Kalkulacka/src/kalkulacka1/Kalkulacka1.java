package kalkulacka1;

import view.View;

public class Kalkulacka1 {
    public static void main(String[] args) {
        View view = new View();
        view.setVisible(true);
    }
}
