package mat_sibenice;

import view.View;

public class MAT_Sibenice {
    public static void main(String[] args) {
        View view = new View();
        view.setVisible(true);
    }
}
